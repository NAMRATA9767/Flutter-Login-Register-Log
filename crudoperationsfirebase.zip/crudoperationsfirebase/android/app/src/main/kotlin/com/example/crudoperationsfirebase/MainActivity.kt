package com.example.crudoperationsfirebase

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
