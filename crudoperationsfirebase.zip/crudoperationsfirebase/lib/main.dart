//import 'package:crudoperationsfirebase/SignUp.dart';
import 'package:crudoperationsfirebase/Login.dart';
import 'package:crudoperationsfirebase/start.dart';
//import 'package:crudoperationsfirebase/start.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
//import 'package:crudoperationsfirebase/HomePage.dart';

void main() async => runApp(MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
          brightness: Brightness.light,
          primaryColor: Colors.orange,
          accentColor: Colors.cyan),
      home: Start(),
    ));
// Future<FirebaseFirestore>  async .initializeApp(); //<-- where the magic happens

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  FirebaseAuth _auth = FirebaseAuth.instance;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
// final String DetailsEmp;

//   GetUserName(this.DetailsEmp);

  String EmployeeName,
      EmployeeID,
      Employeeemail,
      Employeepassword,
      Employeephone,
      EmployeeCode;
  checkAuthentication() async {
    _auth.authStateChanges().listen((user) async {
      if (user != null) {
        Navigator.pushReplacementNamed(context, "/HomePage");
      }
    });
  }

  @override
  void initState() {
    super.initState();
    this.checkAuthentication();
  }

  signUp(checkEmail, checkPass) async {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();

      try {
        UserCredential user = await _auth.createUserWithEmailAndPassword(
            email: checkEmail, password: checkPass);
        if (user != null) {
          // UserUpdateInfo updateuser = UserUpdateInfo();
          // updateuser.displayName = _name;
          //  user.updateProfile(updateuser);
          await _auth.currentUser.updateProfile(displayName: EmployeeName);
          // await Navigator.pushReplacementNamed(context,"/") ;

        }
      } catch (e) {
        showError(e.message);
        print(e);
      }
    }
  }

  showError(String errormessage) {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('ERROR'),
            content: Text(errormessage),
            actions: <Widget>[
              FlatButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Text('OK'))
            ],
          );
        });
  }

  getEmployeeName(name) {
    this.EmployeeName = name;
  }

  getEmployeeID(id) {
    this.EmployeeID = id;
  }

  getEmployeeEmail(EmailID) {
    this.Employeeemail = EmailID;
  }

  getEmployeePassword(password) {
    this.Employeepassword = password;
  }

  getEmployeePhone(phone) {
    this.Employeephone = phone;
  }

  getEmployeeCode(code) {
    this.EmployeeCode = code;
  }

  createData() {
    print("REGISTERED");
    WidgetsFlutterBinding.ensureInitialized();

    Firebase.initializeApp();
    //.initializeApp();

    DocumentReference documentReference =
        FirebaseFirestore.instance.collection("DetailsEmp").doc(Employeeemail);

    Map<String, dynamic> employees = {
      "EmployeeName": EmployeeName,
      "EmployeeID": EmployeeID,
      "EmployeeEmail": Employeeemail,
      "Employeepassword": Employeepassword,
      "Employeephone": Employeephone,
      "EmployeeCode": EmployeeCode
    };
    documentReference.set(employees).whenComplete(() {
      print("$EmployeeName REGISTERED");
      print("$EmployeeID Saved");
    });
    signUp(Employeeemail, Employeepassword);
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => Login()),
    );
  }

  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          title: Text("Employee Registration Page"),
        ),
        body: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(bottom: 6.0),
              child: TextFormField(
                validator: ((input) {
                  if (input.isEmpty) return 'Enter Name';
                }),
                decoration: InputDecoration(
                    prefixIcon: Icon(Icons.person),
                    labelText: "UserName",
                    fillColor: Colors.white,
                    focusedBorder: OutlineInputBorder(
                        borderSide:
                            BorderSide(color: Colors.pink, width: 2.0))),
                onChanged: (String name) {
                  getEmployeeName(name);
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 6.0),
              child: TextFormField(
                  validator: (input) {
                    if (input.isEmpty) return 'Enter Email';
                  },
                  decoration: InputDecoration(
                      labelText: "Email ",
                      prefixIcon: Icon(Icons.email),
                      fillColor: Colors.white,
                      focusedBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Colors.pink, width: 2.0))),
                  onChanged: (String email) {
                    getEmployeeEmail(email);
                  }),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 6.0),
              child: TextFormField(
                  validator: (input) {
                    if (input.isEmpty) return 'Enter phone';
                  },
                  decoration: InputDecoration(
                      prefixIcon: Icon(Icons.phone),
                      labelText: "Phone",
                      fillColor: Colors.white,
                      focusedBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Colors.pink, width: 2.0))),
                  onChanged: (String phone) {
                    getEmployeePhone(phone);
                  }),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 6.0),
              child: TextFormField(
                validator: (input) {
                  if (input.isEmpty) return 'Enter employee code';
                },
                decoration: InputDecoration(
                    prefixIcon: Icon(Icons.code),
                    labelText: "Employee Code",
                    fillColor: Colors.white,
                    focusedBorder: OutlineInputBorder(
                        borderSide:
                            BorderSide(color: Colors.pink, width: 2.0))),
                onChanged: (String code) {
                  getEmployeeCode(code);
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 6.0),
              child: TextFormField(
                  validator: (input) {
                    if (input.isEmpty) return 'Enter password';
                  },
                  decoration: InputDecoration(
                      prefixIcon: Icon(Icons.accessible_sharp),
                      labelText: "Password",
                      fillColor: Colors.white,
                      focusedBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Colors.pink, width: 2.0))),
                  onChanged: (String password) {
                    getEmployeePassword(password);
                  }),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 6.0),
              child: TextFormField(
                  validator: (input) {
                    if (input.isEmpty) return 'Enter Employee ID';
                  },
                  decoration: InputDecoration(
                      prefixIcon: Icon(Icons.important_devices),
                      labelText: "Employee ID",
                      fillColor: Colors.white,
                      focusedBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: Colors.pink, width: 2.0))),
                  onChanged: (String id) {
                    getEmployeeID(id);
                  }),
            ),
            SizedBox(height: 20.0),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                RaisedButton(
                  color: Colors.red,
                  padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16.0)),
                  child: Text("REGISTER"),
                  textColor: Colors.white,
                  onPressed: () {
                    createData();

                    //
                  },
                ),
              ],
            ),
          ]),
        ));
  }
}
